import React, { useState } from "react";
import ClickTimes from "./ClickTimes";
import TimestampsDisplay from "./TimestampsDisplay";

function App() {
  const timestamps = [1000000000000, 1000000001000];
  return <TimestampsDisplay timestamps={timestamps} />;
}

export default App;

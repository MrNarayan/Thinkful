import React from "react";

function ClickTimes() {}

export default ClickTimes;

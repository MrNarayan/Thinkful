import React from "react";
import "./Header.css";

/*
  TODO: Complete the header
*/

function Header({name="Unknown Name",birthday="Unknown birthday",imageSrc="",}) {
  return (
    <header>

    
    </header>
  );
}

export default Header;

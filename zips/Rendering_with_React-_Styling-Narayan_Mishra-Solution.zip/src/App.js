import React from "react";

function App() {
  return (
    <div>
      <h1>Hello!</h1>
      <h4>How are you?</h4>
      <h5>Today is a nice day!</h5>
    </div>
  );
}

export default App;

import React from "react";
import IncrementButtons from "./IncrementButtons";

function App() {
  return <IncrementButtons />;
}

export default App;

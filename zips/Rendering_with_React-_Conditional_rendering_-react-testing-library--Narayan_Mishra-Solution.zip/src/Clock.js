import React from "react";

function Clock() {
  // write your code here
}

export default Clock;

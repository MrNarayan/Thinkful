import React from "react";

function Roster({ detailed, roster }) {
  return <p>Replace this with your solution.</p>
}

export default Roster;
